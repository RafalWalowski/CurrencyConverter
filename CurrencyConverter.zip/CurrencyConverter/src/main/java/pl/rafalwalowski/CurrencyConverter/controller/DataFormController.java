package pl.rafalwalowski.CurrencyConverter.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import pl.rafalwalowski.CurrencyConverter.models.DataForm;
import pl.rafalwalowski.CurrencyConverter.service.DataFormService;

import java.io.IOException;

@Controller
public class DataFormController {

    @GetMapping("/")
    public String viewDataForm(Model model){
        model.addAttribute("dataForm", new DataForm());
        return "view";
    }

    @PostMapping("/")
    public String sendDataForm(@ModelAttribute DataForm dataForm, Model model) throws IOException, InterruptedException {
        DataFormService dataFormService = new DataFormService(dataForm);
        dataFormService.sendResult();
        model.addAttribute("dataForm", dataForm);
        return "view";
    }
}
