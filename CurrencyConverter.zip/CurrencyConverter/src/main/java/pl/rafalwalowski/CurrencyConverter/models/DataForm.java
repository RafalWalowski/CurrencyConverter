package pl.rafalwalowski.CurrencyConverter.models;

import lombok.Data;
import org.springframework.stereotype.Component;

@Component
@Data
public class DataForm {
    private String amount;
    private String from;
    private String to;
    private String result;

}
