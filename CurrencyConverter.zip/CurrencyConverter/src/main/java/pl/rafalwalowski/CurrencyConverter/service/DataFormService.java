package pl.rafalwalowski.CurrencyConverter.service;

import org.springframework.stereotype.Service;
import pl.rafalwalowski.CurrencyConverter.models.DataForm;

import java.io.IOException;
@Service
public class DataFormService {
    DataForm dataForm;

    public DataFormService(DataForm dataForm) {
        this.dataForm = dataForm;
    }

    public void sendResult() throws IOException, InterruptedException {
        ServiceHttp serviceHttp = new ServiceHttp(dataForm.getAmount(), dataForm.getFrom(), dataForm.getTo(), dataForm);
        serviceHttp.connect();
    }

}
