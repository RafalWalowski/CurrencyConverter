package pl.rafalwalowski.CurrencyConverter.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import pl.rafalwalowski.CurrencyConverter.models.DataForm;
import pl.rafalwalowski.CurrencyConverter.models.ObjectJSON;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

public class ServiceHttp {
    DataForm dataForm;
    private final String apiKey = "bc9235d4e88485864e784a2b";
    String url;


    public ServiceHttp(String amount, String from, String to, DataForm dataForm) {
        url = "https://v6.exchangerate-api.com/v6/" + apiKey + "/pair/" + from + "/" + to + "/" + amount;
        this.dataForm = dataForm;
    }

    public void connect() throws IOException, InterruptedException {
        HttpClient client = HttpClient.newHttpClient();
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .GET()
                .build();

        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

        if (response.statusCode() >= 200 && response.statusCode() < 300) {
            ObjectMapper objectMapper = new ObjectMapper();
            ObjectJSON objectJSON = objectMapper.readValue(response.body(), ObjectJSON.class);
            String result = String.valueOf(objectJSON.conversion_result);
            dataForm.setResult(result + " " + dataForm.getTo());
        }
    }
}
