package pl.rafalwalowski.CurrencyConverter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CurrencyConvertorApplicationTests {

	@Test
	void contextLoads() {
	}

}
